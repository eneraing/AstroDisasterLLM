import os
import pandas as pd
import openai
import time
from datetime import datetime
import csv
import json
import re
import numpy as np

# 设置OpenAI API密钥
# 注意：在生产环境中，应该从环境变量或配置文件中读取API密钥，而不是硬编码
api_key = os.getenv("OPENAI_API_KEY", "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")
os.environ["OPENAI_API_KEY"] = api_key
openai.api_key = api_key

# 加载数据
def load_data():
    """
    加载ATEL数据和样例标注数据

    Returns:
        tuple: (atel_data, sample_data) 或 (None, None) 如果加载失败
    """
    def try_read_csv(filename):
        """尝试使用不同编码读取CSV文件"""
        encodings = ['utf-8', 'gbk', 'gb2312', 'utf-8-sig', 'latin1', 'cp1252']

        for encoding in encodings:
            try:
                print(f"尝试使用 {encoding} 编码读取 {filename}...")
                data = pd.read_csv(filename, encoding=encoding)
                print(f"成功使用 {encoding} 编码读取 {filename}")

                # 验证数据完整性
                if data.empty:
                    print(f"警告: {filename} 文件为空")
                else:
                    print(f"文件 {filename} 包含 {len(data)} 行数据")
                    print(f"列名: {list(data.columns)}")

                return data
            except UnicodeDecodeError:
                continue
            except Exception as e:
                print(f"使用 {encoding} 编码读取 {filename} 时出错: {e}")
                continue

        raise Exception(f"无法使用任何编码读取文件 {filename}")

    try:
        # 加载天文事件数据
        atel_data = try_read_csv('atel_results_20250724_190413.csv')

        # 验证ATEL数据的必要列
        required_columns = ['编号', '标题', '内容']
        missing_columns = [col for col in required_columns if col not in atel_data.columns]
        if missing_columns:
            print(f"警告: ATEL数据缺少必要列: {missing_columns}")

        # 尝试加载样例标注数据（可选）
        sample_data = None
        try:
            sample_data = try_read_csv('样例标注.csv')
        except Exception as e:
            print(f"样例标注数据加载失败（可选文件）: {e}")

        print(f"成功加载ATEL数据: {len(atel_data)}条天文事件记录")
        if sample_data is not None:
            print(f"成功加载样例标注数据: {len(sample_data)}条记录")

        return atel_data, sample_data
    except Exception as e:
        print(f"加载数据时出错: {e}")
        return None, None

# 构建系统提示
def get_system_prompt():
    return """
    你是一个专业的天文学助手，专门处理和分析天文事件数据。
    你可以帮助用户查询、分析和解释各种天文事件，如超新星、快速射电暴、伽马射线爆等。
    请基于提供的数据回答问题，如果数据中没有相关信息，请明确说明。
    
    数据包含以下字段:
    - event_type: 事件类型，如超新星、快速射电暴、伽马射线爆等
    - event_id: 事件唯一标识符
    - instrument: 探测设备名称
    - date: 探测日期
    - frequency_band: 观测频段
    - duration: 事件持续时间
    - peak_flux: 最大亮度或强度
    - counterpart_detected: 是否有多波段探测结果
    
    当用户请求提取结构化信息时，请按照以下JSON格式返回数据:
    ```json
    {
        "event_type": "事件类型",
        "event_id": "事件ID",
        "instrument": "观测设备",
        "date": "日期",
        "frequency_band": "频段",
        "duration": "持续时间",
        "peak_flux": "最大亮度",
        "counterpart_detected": true/false
    }
    ```
    
    如果某些字段在数据中未提及，请将其值设为null。
    """

# 从数据中提取相关信息作为上下文
def get_context_from_data(atel_data, query, max_items=5):
    """
    从ATEL数据中提取与查询相关的信息作为上下文

    Args:
        atel_data: pandas DataFrame，包含ATEL数据
        query: str，用户查询
        max_items: int，最大返回项目数

    Returns:
        str: 格式化的上下文信息
    """
    relevant_items = []

    if atel_data is None or atel_data.empty:
        return "数据为空，无法提供相关信息。"

    # 将查询转换为小写以进行不区分大小写的匹配
    query_lower = query.lower()

    # 扩展的事件ID和设备名称匹配模式
    event_patterns = [
        r'(SN|FRB|GRB|AT)\s*\d{4}[a-zA-Z]*',  # 超新星、快速射电暴、伽马射线爆等
        r'PSR\s*[BJ]?\d{4}[+-]\d{2,4}',        # 脉冲星
        r'SGR\s*\d{4}[+-]\d{2,4}',             # 软伽马重复源
        r'MAXI\s*[JG]\d{6}[+-]\d{6}',          # MAXI源
    ]

    instrument_patterns = [
        r'(NuSTAR|CHIME|Swift|Fermi|LIGO|ALMA|Chandra|XMM|Hubble|JWST)',
        r'(MAXI|NICER|RXTE|Spitzer|Kepler|TESS|Gaia)',
        r'(VLA|VLBA|ASKAP|MeerKAT|FAST|Arecibo)',
        r'(Lovell|Jodrell|Parkes|GBT|Effelsberg)'
    ]

    # 提取查询中的关键信息
    event_matches = []
    for pattern in event_patterns:
        matches = re.findall(pattern, query, re.IGNORECASE)
        event_matches.extend(matches)

    instrument_matches = []
    for pattern in instrument_patterns:
        matches = re.findall(pattern, query, re.IGNORECASE)
        instrument_matches.extend(matches)

    # 在标题和内容中搜索关键词
    for _, row in atel_data.iterrows():
        try:
            title = str(row['标题']).lower() if pd.notna(row['标题']) else ""
            content = str(row['内容']).lower() if pd.notna(row['内容']) else ""

            # 基础关键词匹配
            basic_match = query_lower in title or query_lower in content

            # 特定事件ID匹配
            event_match = any(event.lower() in title or event.lower() in content
                            for event in event_matches)

            # 特定设备匹配
            instrument_match = any(inst.lower() in title or inst.lower() in content
                                 for inst in instrument_matches)

            # 计算相关性得分
            relevance_score = 0
            if basic_match:
                relevance_score += 1
            if event_match:
                relevance_score += 2
            if instrument_match:
                relevance_score += 1

            if relevance_score > 0:
                # 截断内容以避免过长
                content_preview = row['内容'][:1000] + "..." if len(str(row['内容'])) > 1000 else row['内容']

                relevant_items.append({
                    "编号": row['编号'],
                    "标题": row['标题'],
                    "内容": content_preview,
                    "相关性": relevance_score
                })

        except Exception as e:
            print(f"处理行数据时出错: {e}")
            continue

    # 按相关性得分排序
    relevant_items.sort(key=lambda x: x['相关性'], reverse=True)
    relevant_items = relevant_items[:max_items]

    # 构建上下文字符串
    if relevant_items:
        context = f"找到 {len(relevant_items)} 条与您的查询相关的天文事件信息:\n\n"
        for i, item in enumerate(relevant_items, 1):
            context += f"[{i}] 编号: {item['编号']}\n"
            context += f"标题: {item['标题']}\n"
            context += f"内容: {item['内容']}\n"
            context += f"相关性得分: {item['相关性']}\n\n"
    else:
        context = "未找到与您的查询直接相关的天文事件信息。请尝试使用更具体的关键词，如事件名称、设备名称或天体类型。"

    return context

# 从ATEL内容中提取结构化信息
def extract_structured_info_from_content(content):
    """
    从ATEL内容中提取结构化信息

    Args:
        content: str, ATEL内容文本

    Returns:
        dict: 提取的结构化信息
    """
    extracted_info = {
        "event_type": None,
        "event_id": None,
        "instrument": None,
        "date": None,
        "frequency_band": None,
        "duration": None,
        "peak_flux": None,
        "counterpart_detected": None,
        "coordinates": None,
        "distance": None
    }

    if not content:
        return extracted_info

    content_lower = content.lower()

    # 提取事件类型
    event_type_patterns = {
        "Supernovae": [r"supernova", r"sn\s+\d{4}", r"type\s+i[a-z]*"],
        "Fast Radio Burst": [r"fast radio burst", r"frb", r"frb\s+\d{6}"],
        "Gamma-ray Burst": [r"gamma.?ray burst", r"grb", r"grb\s+\d{6}"],
        "Pulsar": [r"pulsar", r"psr\s+[bj]?\d{4}"],
        "Magnetar": [r"magnetar", r"sgr\s+\d{4}"],
        "X-ray Transient": [r"x.?ray transient", r"x.?ray source"],
        "Gravitational Wave": [r"gravitational wave", r"ligo", r"gw\d{6}"]
    }

    for event_type, patterns in event_type_patterns.items():
        if any(re.search(pattern, content_lower) for pattern in patterns):
            extracted_info["event_type"] = event_type
            break

    # 提取事件ID
    event_id_patterns = [
        r"(SN\s*\d{4}[a-zA-Z]*)",
        r"(FRB\s*\d{6}[a-zA-Z]*)",
        r"(GRB\s*\d{6}[a-zA-Z]*)",
        r"(PSR\s*[BJ]?\d{4}[+-]\d{2,4})",
        r"(SGR\s*\d{4}[+-]\d{2,4})",
        r"(AT\s*\d{4}[a-zA-Z]*)",
        r"(GW\d{6})"
    ]

    for pattern in event_id_patterns:
        match = re.search(pattern, content, re.IGNORECASE)
        if match:
            extracted_info["event_id"] = match.group(1).strip()
            break

    # 提取观测设备
    instrument_patterns = [
        r"(NuSTAR|CHIME|Swift|Fermi|LIGO|ALMA|Chandra|XMM|Hubble|JWST)",
        r"(MAXI|NICER|RXTE|Spitzer|Kepler|TESS|Gaia)",
        r"(VLA|VLBA|ASKAP|MeerKAT|FAST|Arecibo)",
        r"(Lovell|Jodrell|Parkes|GBT|Effelsberg)"
    ]

    instruments = []
    for pattern in instrument_patterns:
        matches = re.findall(pattern, content, re.IGNORECASE)
        instruments.extend(matches)

    if instruments:
        extracted_info["instrument"] = ", ".join(set(instruments))

    # 提取日期
    date_patterns = [
        r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})",  # ISO format
        r"(\d{4}-\d{2}-\d{2})",  # Date only
        r"(MJD\s*\d{5,6})",  # Modified Julian Date
        r"(\d{1,2}\s+\w+\s+\d{4})"  # 23 Jul 2025
    ]

    for pattern in date_patterns:
        match = re.search(pattern, content, re.IGNORECASE)
        if match:
            extracted_info["date"] = match.group(1).strip()
            break

    # 提取频段信息
    frequency_patterns = [
        r"(\d+\.?\d*\s*-\s*\d+\.?\d*\s*keV)",
        r"(\d+\.?\d*\s*keV)",
        r"(\d+\.?\d*\s*MHz)",
        r"(\d+\.?\d*\s*GHz)",
        r"(optical|radio|x-ray|gamma-ray|infrared|ultraviolet)"
    ]

    for pattern in frequency_patterns:
        match = re.search(pattern, content, re.IGNORECASE)
        if match:
            extracted_info["frequency_band"] = match.group(1).strip()
            break

    # 提取持续时间
    duration_patterns = [
        r"(\d+\.?\d*\s*days?)",
        r"(\d+\.?\d*\s*hours?)",
        r"(\d+\.?\d*\s*minutes?)",
        r"(\d+\.?\d*\s*seconds?)",
        r"(\d+\.?\d*\s*ks)",  # kiloseconds
        r"(\d+\.?\d*\s*ms)"   # milliseconds
    ]

    for pattern in duration_patterns:
        match = re.search(pattern, content, re.IGNORECASE)
        if match:
            extracted_info["duration"] = match.group(1).strip()
            break

    # 提取距离信息
    distance_patterns = [
        r"(\d+\.?\d*\s*Mpc)",
        r"(\d+\.?\d*\s*kpc)",
        r"(\d+\.?\d*\s*pc)",
        r"(z\s*=\s*\d+\.?\d*)"  # redshift
    ]

    for pattern in distance_patterns:
        match = re.search(pattern, content, re.IGNORECASE)
        if match:
            extracted_info["distance"] = match.group(1).strip()
            break

    return extracted_info

# 使用OpenAI API进行对话
def chat_with_openai(messages, extract_structured_data=False):
    try:
        if extract_structured_data:
            # 添加额外指令，要求模型提取结构化数据
            messages.append({
                "role": "user", 
                "content": "请从上述内容中提取结构化数据，按照系统提示中的JSON格式返回。只返回JSON数据，不要有其他文字。"
            })
        
        response = openai.ChatCompletion.create(
            model="gpt-4",  # 或者使用其他可用模型
            messages=messages,
            temperature=0.7,
            max_tokens=1500
        )
        
        content = response.choices[0].message["content"]
        
        # 如果是结构化数据提取，尝试解析JSON
        if extract_structured_data:
            try:
                # 提取JSON部分
                json_match = re.search(r'```json\s*(.+?)\s*```', content, re.DOTALL)
                if json_match:
                    json_str = json_match.group(1)
                else:
                    json_str = content
                
                # 解析JSON
                structured_data = json.loads(json_str)
                return structured_data
            except json.JSONDecodeError:
                return {"error": "无法解析结构化数据", "raw_content": content}
        
        return content
    except Exception as e:
        return f"与AI对话时出错: {e}"

# 保存对话历史
def save_conversation(conversation_history, filename=None):
    if filename is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"conversation_{timestamp}.csv"
    
    with open(filename, 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(["角色", "内容"])
        
        for message in conversation_history:
            writer.writerow([message["role"], message["content"]])
    
    print(f"对话已保存至 {filename}")

# 保存结构化数据
def save_structured_data(data, filename=None):
    if filename is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"structured_data_{timestamp}.json"

    with open(filename, 'w', encoding='utf-8') as file:
        json.dump(data, file, ensure_ascii=False, indent=4)

    print(f"结构化数据已保存至 {filename}")

# 数据集划分和准确率评估功能
def evaluate_structured_extraction_accuracy(atel_data, sample_data=None, test_size=0.2, random_state=42):
    """
    评估结构化信息提取的准确率和精度

    Args:
        atel_data: pandas DataFrame，包含ATEL数据
        sample_data: pandas DataFrame，包含样例标注数据
        test_size: float，测试集比例
        random_state: int，随机种子

    Returns:
        dict: 包含评估结果的字典
    """
    print("开始评估结构化信息提取的准确率...")

    # 如果有样例标注数据，使用它作为真实标签
    if sample_data is not None and not sample_data.empty:
        print("使用样例标注数据进行评估...")
        return evaluate_with_sample_data(sample_data)

    # 如果没有样例标注数据，使用ATEL数据进行自动评估
    print("使用ATEL数据进行自动评估...")
    return evaluate_with_atel_data(atel_data, test_size, random_state)

def evaluate_with_sample_data(sample_data):
    """
    使用样例标注数据进行评估
    """
    results = {
        'total_samples': len(sample_data),
        'successful_extractions': 0,
        'failed_extractions': 0,
        'field_accuracy': {},
        'extraction_results': []
    }

    # 定义要评估的字段
    target_fields = ['event_type', 'event_id', 'instrument', 'date',
                    'frequency_band', 'duration', 'peak_flux', 'counterpart_detected']

    # 初始化字段准确率统计
    for field in target_fields:
        results['field_accuracy'][field] = {'correct': 0, 'total': 0, 'accuracy': 0.0}

    for idx, row in sample_data.iterrows():
        try:
            # 获取原始文本和真实标签
            text = row['text']
            true_label = json.loads(row['label'])

            # 使用AI提取结构化信息
            extracted_info = extract_structured_info_with_ai(text)

            if extracted_info and not isinstance(extracted_info, str):
                results['successful_extractions'] += 1

                # 比较每个字段的准确性
                field_comparison = {}
                for field in target_fields:
                    true_value = true_label.get(field)
                    extracted_value = extracted_info.get(field)

                    # 标准化比较
                    is_correct = compare_field_values(true_value, extracted_value, field)
                    field_comparison[field] = {
                        'true': true_value,
                        'extracted': extracted_value,
                        'correct': is_correct
                    }

                    # 更新字段准确率统计
                    if true_value is not None:  # 只统计有真实值的字段
                        results['field_accuracy'][field]['total'] += 1
                        if is_correct:
                            results['field_accuracy'][field]['correct'] += 1

                results['extraction_results'].append({
                    'index': idx,
                    'extraction_successful': True,
                    'field_comparison': field_comparison
                })
            else:
                results['failed_extractions'] += 1
                results['extraction_results'].append({
                    'index': idx,
                    'extraction_successful': False,
                    'error': extracted_info if isinstance(extracted_info, str) else "Unknown error"
                })

        except Exception as e:
            results['failed_extractions'] += 1
            results['extraction_results'].append({
                'index': idx,
                'extraction_successful': False,
                'error': str(e)
            })

    # 计算最终的字段准确率
    for field in target_fields:
        if results['field_accuracy'][field]['total'] > 0:
            results['field_accuracy'][field]['accuracy'] = (
                results['field_accuracy'][field]['correct'] /
                results['field_accuracy'][field]['total']
            )

    # 计算总体准确率
    results['overall_accuracy'] = results['successful_extractions'] / results['total_samples']

    return results

def estimate_tokens(text):
    """
    粗略估算文本的token数量（1个token约等于4个字符）
    """
    return len(text) // 4

def extract_structured_info_with_ai(text, max_retries=3):
    """
    使用AI从文本中提取结构化信息，带重试机制

    Args:
        text: str，输入文本
        max_retries: int，最大重试次数

    Returns:
        dict: 提取的结构化信息，或错误信息字符串
    """
    for attempt in range(max_retries):
        try:
            # 检查输入文本长度，如果太长则进一步截断
            if len(text) > 3000:  # 进一步限制长度
                # 保留标题和内容的前部分
                lines = text.split('\n')
                title_line = lines[0] if lines else ""
                content_lines = lines[1:] if len(lines) > 1 else []
                content_text = '\n'.join(content_lines)

                if len(content_text) > 2500:
                    content_text = content_text[:2500] + "...[截断]"

                text = f"{title_line}\n{content_text}"

            # 构建简化的提示以节省token
            extraction_prompt = f"""从以下天文事件文本提取JSON格式信息：

{text}

提取字段：event_type, event_id, instrument, date, frequency_band, duration, peak_flux, counterpart_detected

只返回JSON，无其他文字。未知字段设为null。

示例：{{"event_type": "Fast Radio Burst", "event_id": "FRB 20220912A", "instrument": "CHIME", "date": "2022-09-12", "frequency_band": "400-800 MHz", "duration": "3 ms", "peak_flux": null, "counterpart_detected": false}}
"""

            # 估算token数量
            estimated_tokens = estimate_tokens(extraction_prompt)
            if estimated_tokens > 3000:  # GPT-3.5-turbo的上下文限制是4096
                return f"输入文本过长，估算token数: {estimated_tokens}"

            # 调用OpenAI API，使用更小的模型和更少的token
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",  # 使用更便宜、更快的模型
                messages=[
                    {"role": "system", "content": "提取天文事件结构化信息，返回JSON格式。"},
                    {"role": "user", "content": extraction_prompt}
                ],
                temperature=0.1,
                max_tokens=300  # 减少输出token数量
            )

            content = response.choices[0].message["content"].strip()

            # 尝试解析JSON
            try:
                # 移除可能的markdown代码块标记
                if content.startswith("```json"):
                    content = content[7:]
                if content.endswith("```"):
                    content = content[:-3]
                content = content.strip()

                structured_data = json.loads(content)
                return structured_data
            except json.JSONDecodeError as e:
                return f"JSON解析错误: {e}, 原始内容: {content}"

        except Exception as e:
            error_msg = str(e)
            print(f"  尝试 {attempt + 1}/{max_retries} 失败: {error_msg}")

            # 如果是API错误且还有重试机会，等待后重试
            if attempt < max_retries - 1:
                if "502" in error_msg or "503" in error_msg or "timeout" in error_msg.lower():
                    wait_time = (attempt + 1) * 5  # 递增等待时间：5秒、10秒、15秒
                    print(f"  等待 {wait_time} 秒后重试...")
                    time.sleep(wait_time)
                    continue
                else:
                    # 非临时性错误，直接返回
                    return f"AI提取错误: {error_msg}"
            else:
                # 最后一次尝试失败
                return f"AI提取错误 (重试{max_retries}次后失败): {error_msg}"

    return "AI提取错误: 未知错误"

def compare_field_values(true_value, extracted_value, field_name):
    """
    比较两个字段值是否匹配

    Args:
        true_value: 真实值
        extracted_value: 提取值
        field_name: 字段名称

    Returns:
        bool: 是否匹配
    """
    # 处理None值
    if true_value is None and extracted_value is None:
        return True
    if true_value is None or extracted_value is None:
        return False

    # 转换为字符串进行比较
    true_str = str(true_value).lower().strip()
    extracted_str = str(extracted_value).lower().strip()

    # 特殊字段的比较逻辑
    if field_name == 'counterpart_detected':
        # 布尔值比较
        return bool(true_value) == bool(extracted_value)

    elif field_name == 'date':
        # 日期比较，允许格式差异
        return normalize_date(true_str) == normalize_date(extracted_str)

    elif field_name in ['peak_flux', 'frequency_band']:
        # 数值和单位比较，允许格式差异
        return normalize_scientific_notation(true_str) == normalize_scientific_notation(extracted_str)

    else:
        # 一般字符串比较，允许小的差异
        return fuzzy_string_match(true_str, extracted_str)

def normalize_date(date_str):
    """标准化日期格式"""
    if not date_str:
        return ""

    # 移除常见的分隔符和空格
    normalized = re.sub(r'[^\d]', '', date_str)
    return normalized

def normalize_scientific_notation(value_str):
    """标准化科学计数法和单位"""
    if not value_str:
        return ""

    # 移除空格并统一格式
    normalized = re.sub(r'\s+', '', value_str)
    # 统一科学计数法格式
    normalized = re.sub(r'(\d+\.?\d*)\s*[×x]\s*10\^?(-?\d+)', r'\1e\2', normalized)
    return normalized

def fuzzy_string_match(str1, str2, threshold=0.8):
    """模糊字符串匹配"""
    if str1 == str2:
        return True

    # 简单的相似度计算
    if len(str1) == 0 or len(str2) == 0:
        return False

    # 计算编辑距离相似度
    max_len = max(len(str1), len(str2))
    edit_distance = levenshtein_distance(str1, str2)
    similarity = 1 - (edit_distance / max_len)

    return similarity >= threshold

def levenshtein_distance(s1, s2):
    """计算编辑距离"""
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)

    if len(s2) == 0:
        return len(s1)

    previous_row = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row

    return previous_row[-1]

def evaluate_with_atel_data(atel_data, test_size=0.2, random_state=42):
    """
    使用ATEL数据进行自动评估
    """
    print("正在使用ATEL数据进行自动评估...")

    # 设置随机种子
    np.random.seed(random_state)

    # 随机选择一部分数据进行评估
    sample_size = min(int(len(atel_data) * test_size), 50)  # 限制样本大小以控制API调用成本
    sample_indices = np.random.choice(len(atel_data), sample_size, replace=False)
    sample_data = atel_data.iloc[sample_indices]

    results = {
        'total_samples': len(sample_data),
        'successful_extractions': 0,
        'failed_extractions': 0,
        'extraction_results': []
    }

    for _, row in sample_data.iterrows():
        try:
            # 构建输入文本
            text = f"标题: {row['标题']}\n内容: {row['内容']}"

            # 使用AI提取结构化信息
            extracted_info = extract_structured_info_with_ai(text)

            if extracted_info and not isinstance(extracted_info, str):
                results['successful_extractions'] += 1
                results['extraction_results'].append({
                    'atel_number': row['编号'],
                    'extraction_successful': True,
                    'extracted_data': extracted_info
                })
            else:
                results['failed_extractions'] += 1
                results['extraction_results'].append({
                    'atel_number': row['编号'],
                    'extraction_successful': False,
                    'error': extracted_info if isinstance(extracted_info, str) else "Unknown error"
                })

        except Exception as e:
            results['failed_extractions'] += 1
            results['extraction_results'].append({
                'atel_number': row['编号'],
                'extraction_successful': False,
                'error': str(e)
            })

    # 计算成功率
    results['success_rate'] = results['successful_extractions'] / results['total_samples']

    return results

def batch_process_atel_data(atel_data, output_file=None, batch_size=10):
    """
    批量处理ATEL数据，提取结构化信息

    Args:
        atel_data: pandas DataFrame，ATEL数据
        output_file: str，输出文件名
        batch_size: int，批处理大小

    Returns:
        list: 处理结果列表
    """
    if output_file is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"batch_structured_data_{timestamp}.json"

    results = []
    total_records = len(atel_data)

    print(f"开始批量处理 {total_records} 条ATEL记录...")

    for i in range(0, total_records, batch_size):
        batch_end = min(i + batch_size, total_records)
        batch_data = atel_data.iloc[i:batch_end]

        print(f"处理批次 {i//batch_size + 1}/{(total_records-1)//batch_size + 1} "
              f"(记录 {i+1}-{batch_end})")

        for _, row in batch_data.iterrows():
            try:
                # 构建输入文本
                text = f"标题: {row['标题']}\n内容: {row['内容']}"

                # 使用AI提取结构化信息
                extracted_info = extract_structured_info_with_ai(text)

                result = {
                    'atel_number': row['编号'],
                    'title': row['标题'],
                    'processing_successful': True,
                    'extracted_data': extracted_info if not isinstance(extracted_info, str) else None,
                    'error': extracted_info if isinstance(extracted_info, str) else None
                }

                results.append(result)

                # 添加延迟以避免API限制
                time.sleep(1)

            except Exception as e:
                result = {
                    'atel_number': row['编号'],
                    'title': row['标题'],
                    'processing_successful': False,
                    'extracted_data': None,
                    'error': str(e)
                }
                results.append(result)

        # 每个批次后保存中间结果
        with open(f"temp_{output_file}", 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)

    # 保存最终结果
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"批量处理完成，结果已保存至 {output_file}")

    # 统计结果
    successful = sum(1 for r in results if r['processing_successful'] and r['extracted_data'])
    failed = len(results) - successful

    print(f"处理统计:")
    print(f"- 总记录数: {len(results)}")
    print(f"- 成功提取: {successful}")
    print(f"- 提取失败: {failed}")
    print(f"- 成功率: {successful/len(results)*100:.2f}%")

    return results

def print_evaluation_report(evaluation_results):
    """
    打印评估报告
    """
    print("\n" + "="*60)
    print("结构化信息提取评估报告")
    print("="*60)

    print(f"总样本数: {evaluation_results['total_samples']}")
    print(f"成功提取: {evaluation_results['successful_extractions']}")
    print(f"提取失败: {evaluation_results['failed_extractions']}")

    if 'overall_accuracy' in evaluation_results:
        print(f"总体准确率: {evaluation_results['overall_accuracy']:.2%}")

    if 'success_rate' in evaluation_results:
        print(f"成功率: {evaluation_results['success_rate']:.2%}")

    # 打印字段准确率（如果有）
    if 'field_accuracy' in evaluation_results:
        print("\n字段准确率:")
        print("-" * 40)
        for field, stats in evaluation_results['field_accuracy'].items():
            if stats['total'] > 0:
                print(f"{field:20}: {stats['accuracy']:.2%} ({stats['correct']}/{stats['total']})")

    print("\n" + "="*60)

# 自动处理所有数据的主函数
def process_all_data_with_ai():
    """
    直接用AI处理数据集的所有数据，并输出处理精度
    """
    print("正在加载天文事件数据...")
    atel_data, sample_data = load_data()

    if atel_data is None:
        print("无法加载数据，程序退出。")
        return

    # 显示数据统计信息
    print(f"\n数据统计:")
    print(f"- ATEL事件数据: {len(atel_data)} 条记录")
    if sample_data is not None:
        print(f"- 样例标注数据: {len(sample_data)} 条记录")
    else:
        print("- 样例标注数据: 未加载")

    # 显示数据列信息
    print(f"- ATEL数据列: {list(atel_data.columns)}")

    # 显示数据预览
    print(f"\n数据预览 (前3条记录的标题):")
    for i, row in atel_data.head(3).iterrows():
        print(f"  {i+1}. {row['标题']}")

    print("\n开始自动处理所有数据...")
    print("="*60)

    # 1. 首先进行精度评估
    print("\n步骤1: 评估AI处理精度")
    print("-" * 40)
    evaluation_results = evaluate_structured_extraction_accuracy(atel_data, sample_data)
    print_evaluation_report(evaluation_results)

    # 保存评估结果
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    eval_filename = f"evaluation_results_{timestamp}.json"
    with open(eval_filename, 'w', encoding='utf-8') as f:
        json.dump(evaluation_results, f, ensure_ascii=False, indent=2)
    print(f"评估结果已保存至 {eval_filename}")

    # 2. 批量处理所有数据
    print(f"\n步骤2: 批量处理所有 {len(atel_data)} 条数据")
    print("-" * 40)

    # 询问是否继续处理所有数据
    if len(atel_data) > 100:
        print(f"警告: 数据量较大({len(atel_data)}条)，处理可能需要较长时间和API费用。")
        confirm = input("是否继续处理所有数据? (y/n): ")
        if confirm.lower() != 'y':
            print("用户取消处理。")
            return

    # 开始批量处理
    batch_results = batch_process_atel_data(atel_data, batch_size=5)  # 减小批次大小以提高稳定性

    # 3. 分析处理结果
    print(f"\n步骤3: 分析处理结果")
    print("-" * 40)

    successful_extractions = [r for r in batch_results
                            if r['processing_successful'] and r['extracted_data']]
    failed_extractions = [r for r in batch_results
                         if not r['processing_successful'] or not r['extracted_data']]

    # 计算详细统计
    total_records = len(batch_results)
    success_count = len(successful_extractions)
    failure_count = len(failed_extractions)
    success_rate = success_count / total_records if total_records > 0 else 0

    print(f"处理完成统计:")
    print(f"- 总记录数: {total_records}")
    print(f"- 成功处理: {success_count}")
    print(f"- 处理失败: {failure_count}")
    print(f"- 成功率: {success_rate:.2%}")

    # 分析提取的字段完整性
    if successful_extractions:
        field_stats = analyze_field_completeness(successful_extractions)
        print(f"\n字段提取完整性分析:")
        for field, stats in field_stats.items():
            print(f"- {field}: {stats['filled']}/{stats['total']} ({stats['percentage']:.1f}%)")

    # 4. 保存综合结果
    print(f"\n步骤4: 保存综合结果")
    print("-" * 40)

    # 创建综合报告
    comprehensive_report = {
        'processing_timestamp': timestamp,
        'data_statistics': {
            'total_atel_records': len(atel_data),
            'sample_data_available': sample_data is not None,
            'sample_data_count': len(sample_data) if sample_data is not None else 0
        },
        'evaluation_results': evaluation_results,
        'batch_processing_results': {
            'total_processed': total_records,
            'successful_extractions': success_count,
            'failed_extractions': failure_count,
            'success_rate': success_rate
        },
        'field_completeness': field_stats if successful_extractions else {},
        'detailed_results': batch_results
    }

    # 保存综合报告
    report_filename = f"comprehensive_processing_report_{timestamp}.json"
    with open(report_filename, 'w', encoding='utf-8') as f:
        json.dump(comprehensive_report, f, ensure_ascii=False, indent=2)
    print(f"综合处理报告已保存至 {report_filename}")

    # 保存成功提取的结构化数据
    if successful_extractions:
        structured_data_filename = f"all_structured_data_{timestamp}.json"
        structured_data_only = [
            {
                'atel_number': r['atel_number'],
                'title': r['title'],
                'extracted_data': r['extracted_data']
            }
            for r in successful_extractions
        ]
        with open(structured_data_filename, 'w', encoding='utf-8') as f:
            json.dump(structured_data_only, f, ensure_ascii=False, indent=2)
        print(f"结构化数据已保存至 {structured_data_filename}")

    # 5. 显示处理示例
    print(f"\n步骤5: 处理结果示例")
    print("-" * 40)

    if successful_extractions:
        print("成功提取的示例 (前3个):")
        for i, result in enumerate(successful_extractions[:3]):
            print(f"\n示例 {i+1} - ATEL #{result['atel_number']}:")
            print(f"标题: {result['title']}")
            print("提取的数据:")
            print(json.dumps(result['extracted_data'], ensure_ascii=False, indent=2))

    if failed_extractions:
        print(f"\n失败案例示例 (前3个):")
        for i, result in enumerate(failed_extractions[:3]):
            print(f"\n失败案例 {i+1} - ATEL #{result['atel_number']}:")
            print(f"标题: {result['title']}")
            print(f"错误: {result['error']}")

    print(f"\n" + "="*60)
    print("所有数据处理完成!")
    print(f"总体成功率: {success_rate:.2%}")
    print(f"详细结果请查看: {report_filename}")
    print("="*60)

def analyze_field_completeness(successful_extractions):
    """
    分析字段提取的完整性
    """
    target_fields = ['event_type', 'event_id', 'instrument', 'date',
                    'frequency_band', 'duration', 'peak_flux', 'counterpart_detected']

    field_stats = {}
    total_records = len(successful_extractions)

    for field in target_fields:
        filled_count = 0
        for result in successful_extractions:
            extracted_data = result.get('extracted_data', {})
            if extracted_data and extracted_data.get(field) is not None:
                filled_count += 1

        field_stats[field] = {
            'filled': filled_count,
            'total': total_records,
            'percentage': (filled_count / total_records * 100) if total_records > 0 else 0
        }

    return field_stats

# 保持原有的交互式主函数作为备选
def interactive_main():
    """
    原有的交互式主函数
    """
    print("正在加载天文事件数据...")
    atel_data, sample_data = load_data()

    if atel_data is None:
        print("无法加载数据，程序退出。")
        return

    # 显示数据统计信息
    print(f"\n数据统计:")
    print(f"- ATEL事件数据: {len(atel_data)} 条记录")
    if sample_data is not None:
        print(f"- 样例标注数据: {len(sample_data)} 条记录")
    else:
        print("- 样例标注数据: 未加载")

    # 显示数据列信息
    print(f"- ATEL数据列: {list(atel_data.columns)}")

    # 显示数据预览
    print(f"\n数据预览 (前3条记录的标题):")
    for i, row in atel_data.head(3).iterrows():
        print(f"  {i+1}. {row['标题']}")

    print("\n欢迎使用高级天文事件对话系统!")
    print("输入您的问题，或使用以下命令:")
    print("- 'exit': 退出程序")
    print("- 'save': 保存对话历史")
    print("- 'extract': 从最近的对话中提取结构化数据")
    print("- 'analyze <编号>': 直接分析指定编号的ATEL记录")
    print("- 'search <关键词>': 搜索包含关键词的ATEL记录")
    print("- 'evaluate': 评估结构化信息提取的准确率")
    print("- 'batch_process': 批量处理ATEL数据并提取结构化信息")
    print("- 'help': 显示帮助信息")

    # 初始化对话历史
    conversation_history = [
        {"role": "system", "content": get_system_prompt()}
    ]

    while True:
        user_input = input("\n您: ")

        if user_input.lower() == 'exit':
            print("感谢使用，再见!")
            break

        elif user_input.lower() == 'save':
            save_conversation(conversation_history)
            continue

        elif user_input.lower() == 'extract':
            print("\n正在从最近的对话中提取结构化数据...")

            # 创建一个临时对话历史副本用于结构化数据提取
            temp_history = conversation_history.copy()

            structured_data = chat_with_openai(temp_history, extract_structured_data=True)

            if isinstance(structured_data, dict) and "error" in structured_data:
                print(f"\n提取结构化数据失败: {structured_data['error']}")
                print(f"原始内容: {structured_data['raw_content']}")
            else:
                print("\n提取的结构化数据:")
                print(json.dumps(structured_data, ensure_ascii=False, indent=4))

                # 询问是否保存结构化数据
                save_choice = input("\n是否保存结构化数据? (y/n): ")
                if save_choice.lower() == 'y':
                    save_structured_data(structured_data)

            continue

        elif user_input.lower().startswith('analyze '):
            # 直接分析指定编号的ATEL记录
            try:
                atel_number = int(user_input.split(' ', 1)[1])
                record = atel_data[atel_data['编号'] == atel_number]

                if record.empty:
                    print(f"\n未找到编号为 {atel_number} 的ATEL记录")
                    continue

                record = record.iloc[0]
                print(f"\n分析ATEL #{atel_number}: {record['标题']}")
                print("-" * 50)

                # 提取结构化信息
                structured_info = extract_structured_info_from_content(record['内容'])

                print("提取的结构化信息:")
                for key, value in structured_info.items():
                    if value:
                        print(f"  {key}: {value}")

                # 询问是否保存
                save_choice = input("\n是否保存结构化数据? (y/n): ")
                if save_choice.lower() == 'y':
                    save_structured_data(structured_info, f"atel_{atel_number}_structured.json")

            except (ValueError, IndexError):
                print("\n请输入有效的ATEL编号，例如: analyze 17303")
            continue

        elif user_input.lower().startswith('search '):
            # 搜索包含关键词的ATEL记录
            try:
                keyword = user_input.split(' ', 1)[1]
                context = get_context_from_data(atel_data, keyword, max_items=10)
                print(f"\n搜索结果:")
                print(context)
            except IndexError:
                print("\n请输入搜索关键词，例如: search supernova")
            continue

        elif user_input.lower() == 'evaluate':
            print("\n开始评估结构化信息提取的准确率...")
            evaluation_results = evaluate_structured_extraction_accuracy(atel_data, sample_data)
            print_evaluation_report(evaluation_results)

            # 询问是否保存评估结果
            save_choice = input("\n是否保存评估结果? (y/n): ")
            if save_choice.lower() == 'y':
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                eval_filename = f"evaluation_results_{timestamp}.json"
                with open(eval_filename, 'w', encoding='utf-8') as f:
                    json.dump(evaluation_results, f, ensure_ascii=False, indent=2)
                print(f"评估结果已保存至 {eval_filename}")
            continue

        elif user_input.lower() == 'batch_process':
            print("\n开始批量处理ATEL数据...")

            # 询问处理数量
            try:
                max_records = input("请输入要处理的最大记录数 (默认50): ").strip()
                if max_records:
                    max_records = int(max_records)
                else:
                    max_records = 50

                # 限制处理数量
                process_data = atel_data.head(max_records)

                print(f"将处理 {len(process_data)} 条记录...")
                confirm = input("确认开始批量处理? (y/n): ")

                if confirm.lower() == 'y':
                    batch_results = batch_process_atel_data(process_data)

                    # 显示处理结果摘要
                    successful_extractions = [r for r in batch_results
                                            if r['processing_successful'] and r['extracted_data']]

                    print(f"\n批量处理完成!")
                    print(f"成功提取结构化数据的记录数: {len(successful_extractions)}")

                    # 显示几个成功的例子
                    if successful_extractions:
                        print("\n成功提取的示例:")
                        for i, result in enumerate(successful_extractions[:3]):
                            print(f"\n示例 {i+1} - ATEL #{result['atel_number']}:")
                            print(json.dumps(result['extracted_data'], ensure_ascii=False, indent=2))

            except ValueError:
                print("请输入有效的数字")
            continue

        elif user_input.lower() == 'help':
            print("\n命令帮助:")
            print("- 'exit': 退出程序")
            print("- 'save': 保存对话历史")
            print("- 'extract': 从最近的对话中提取结构化数据")
            print("- 'analyze <编号>': 直接分析指定编号的ATEL记录")
            print("- 'search <关键词>': 搜索包含关键词的ATEL记录")
            print("- 'evaluate': 评估结构化信息提取的准确率")
            print("- 'batch_process': 批量处理ATEL数据并提取结构化信息")
            print("- 'help': 显示帮助信息")
            continue

        # 获取相关上下文
        context = get_context_from_data(atel_data, user_input)

        # 构建用户消息，包含查询和上下文
        user_message = f"用户查询: {user_input}\n\n相关上下文信息: {context}"

        # 添加到对话历史
        conversation_history.append({"role": "user", "content": user_message})

        print("\nAI思考中...")
        start_time = time.time()

        # 获取AI回复
        ai_response = chat_with_openai(conversation_history)

        # 计算响应时间
        response_time = time.time() - start_time

        # 添加到对话历史
        conversation_history.append({"role": "assistant", "content": ai_response})

        print(f"\nAI: {ai_response}")
        print(f"(响应时间: {response_time:.2f}秒)")

# 随机抽样处理函数
def process_random_sample():
    """
    从400条数据中随机抽样10条进行处理
    """
    print("正在加载天文事件数据...")
    atel_data, _ = load_data()  # 不使用sample_data，用_表示

    if atel_data is None:
        print("无法加载数据，程序退出。")
        return

    # 显示数据统计信息
    print(f"\n数据统计:")
    print(f"- ATEL事件数据: {len(atel_data)} 条记录")

    # 限制数据到400条
    if len(atel_data) > 400:
        atel_data = atel_data.head(400)
        print(f"- 限制处理数据: {len(atel_data)} 条记录")

    # 随机抽样10条
    np.random.seed(42)  # 设置随机种子以确保结果可重现
    sample_size = min(10, len(atel_data))
    sample_indices = np.random.choice(len(atel_data), sample_size, replace=False)
    sample_data_subset = atel_data.iloc[sample_indices]

    print(f"- 随机抽样: {len(sample_data_subset)} 条记录")
    print(f"- 抽样索引: {sorted(sample_indices.tolist())}")

    # 显示抽样的记录标题
    print(f"\n抽样记录预览:")
    for i, (_, row) in enumerate(sample_data_subset.iterrows()):  # 不使用idx，用_表示
        print(f"  {i+1}. [编号:{row['编号']}] {row['标题']}")

    print("\n开始处理抽样数据...")
    print("="*60)

    # 处理抽样数据
    results = []
    total_records = len(sample_data_subset)

    print(f"正在处理 {total_records} 条抽样记录...")

    for i, (_, row) in enumerate(sample_data_subset.iterrows()):
        print(f"\n处理进度: {i+1}/{total_records}")
        print(f"当前处理: ATEL #{row['编号']} - {row['标题'][:80]}{'...' if len(row['标题']) > 80 else ''}")

        try:
            # 构建输入文本，限制内容长度以避免token超限
            title = str(row['标题'])
            content = str(row['内容'])

            # 限制内容长度，保留前2000个字符
            if len(content) > 2000:
                content = content[:2000] + "...[内容已截断]"
                print(f"  内容过长，已截断至2000字符")

            text = f"标题: {title}\n内容: {content}"

            print(f"  输入文本长度: {len(text)} 字符")

            # 使用AI提取结构化信息（带重试机制）
            print("  正在调用AI提取结构化信息...")
            extracted_info = extract_structured_info_with_ai(text)

            # 如果AI提取失败，尝试使用基于规则的提取作为备选
            if isinstance(extracted_info, str) and "AI提取错误" in extracted_info:
                print("  AI提取失败，尝试使用基于规则的提取...")
                extracted_info = extract_structured_info_from_content(text)

            if isinstance(extracted_info, str):
                # 提取失败
                result = {
                    'atel_number': row['编号'],
                    'title': row['标题'],
                    'processing_successful': False,
                    'extracted_data': None,
                    'error': extracted_info
                }
                print(f"✗ 处理失败: {extracted_info}")
            else:
                # 提取成功
                result = {
                    'atel_number': row['编号'],
                    'title': row['标题'],
                    'processing_successful': True,
                    'extracted_data': extracted_info,
                    'error': None
                }
                print("✓ 处理成功")

                # 显示提取的关键信息
                if extracted_info.get('event_type'):
                    print(f"  事件类型: {extracted_info['event_type']}")
                if extracted_info.get('event_id'):
                    print(f"  事件ID: {extracted_info['event_id']}")

            results.append(result)

            # 添加延迟以避免API限制
            print("  等待2秒...")
            time.sleep(2)

        except Exception as e:
            result = {
                'atel_number': row['编号'],
                'title': row['标题'],
                'processing_successful': False,
                'extracted_data': None,
                'error': f"处理异常: {str(e)}"
            }
            results.append(result)
            print(f"✗ 处理异常: {str(e)}")

            # 异常情况下也要等待，避免连续错误
            time.sleep(1)

    # 保存结果
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"random_sample_results_{timestamp}.json"

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"\n处理结果已保存至: {output_file}")

    # 统计结果
    successful = sum(1 for r in results if r['processing_successful'] and r['extracted_data'])
    failed = len(results) - successful

    print(f"\n处理统计:")
    print(f"- 总记录数: {len(results)}")
    print(f"- 成功提取: {successful}")
    print(f"- 提取失败: {failed}")
    print(f"- 成功率: {successful/len(results)*100:.2f}%")

    # 详细的字段级别评估
    if successful > 0:
        field_analysis = analyze_field_extraction_quality(results)
        print(f"\n字段提取质量分析:")
        print("=" * 50)

        target_fields = ['event_type', 'event_id', 'instrument', 'date',
                        'frequency_band', 'duration', 'peak_flux', 'counterpart_detected']

        for field in target_fields:
            stats = field_analysis.get(field, {})
            filled_count = stats.get('filled', 0)
            total_count = stats.get('total', successful)
            valid_count = stats.get('valid', 0)

            fill_rate = (filled_count / total_count * 100) if total_count > 0 else 0
            validity_rate = (valid_count / filled_count * 100) if filled_count > 0 else 0

            print(f"{field:20}: 填充率 {fill_rate:5.1f}% ({filled_count}/{total_count}), "
                  f"有效率 {validity_rate:5.1f}% ({valid_count}/{filled_count})")

        # 计算总体质量分数
        overall_quality = calculate_overall_quality_score(field_analysis, successful)
        print(f"\n总体提取质量分数: {overall_quality:.1f}/100")

        # 显示质量等级
        if overall_quality >= 80:
            quality_grade = "优秀"
        elif overall_quality >= 60:
            quality_grade = "良好"
        elif overall_quality >= 40:
            quality_grade = "一般"
        else:
            quality_grade = "较差"

        print(f"质量等级: {quality_grade}")

    # 显示成功提取的示例
    successful_extractions = [r for r in results if r['processing_successful'] and r['extracted_data']]

    if successful_extractions:
        print(f"\n成功提取的结构化数据示例:")
        print("-" * 60)
        for i, result in enumerate(successful_extractions[:3]):  # 显示前3个成功的例子
            print(f"\n示例 {i+1} - ATEL #{result['atel_number']}:")
            print(f"标题: {result['title']}")
            print("提取的数据:")
            print(json.dumps(result['extracted_data'], ensure_ascii=False, indent=2))
            print("-" * 40)

    # 显示失败案例
    failed_extractions = [r for r in results if not r['processing_successful'] or not r['extracted_data']]
    if failed_extractions:
        print(f"\n失败案例:")
        print("-" * 60)
        for i, result in enumerate(failed_extractions[:2]):  # 显示前2个失败的例子
            print(f"\n失败案例 {i+1} - ATEL #{result['atel_number']}:")
            print(f"标题: {result['title']}")
            print(f"错误: {result['error']}")
            print("-" * 40)

    print(f"\n" + "="*60)
    print("随机抽样处理完成!")
    print(f"成功率: {successful/len(results)*100:.2f}%")
    print(f"详细结果请查看: {output_file}")
    print("="*60)

    return results

def analyze_field_extraction_quality(results):
    """
    分析字段提取的质量，包括填充率和有效性
    """
    target_fields = ['event_type', 'event_id', 'instrument', 'date',
                    'frequency_band', 'duration', 'peak_flux', 'counterpart_detected']

    field_analysis = {}
    successful_results = [r for r in results if r['processing_successful'] and r['extracted_data']]

    for field in target_fields:
        filled_count = 0
        valid_count = 0

        for result in successful_results:
            extracted_data = result.get('extracted_data', {})
            value = extracted_data.get(field)

            # 检查是否填充了值
            if value is not None and value != "" and str(value).lower() != "null":
                filled_count += 1

                # 检查值的有效性
                if is_field_value_valid(field, value):
                    valid_count += 1

        field_analysis[field] = {
            'filled': filled_count,
            'valid': valid_count,
            'total': len(successful_results)
        }

    return field_analysis

def is_field_value_valid(field_name, value):
    """
    检查字段值是否有效/合理
    """
    if value is None or value == "" or str(value).lower() == "null":
        return False

    value_str = str(value).strip()

    if field_name == 'event_type':
        # 检查是否是合理的事件类型
        valid_types = ['supernova', 'fast radio burst', 'gamma-ray burst', 'pulsar',
                      'magnetar', 'x-ray transient', 'gravitational wave', 'nova',
                      'black hole', 'neutron star', 'quasar', 'blazar']
        return any(vtype in value_str.lower() for vtype in valid_types)

    elif field_name == 'event_id':
        # 检查是否符合天文事件ID格式
        import re
        patterns = [
            r'(SN|AT)\s*\d{4}[a-zA-Z]*',  # 超新星
            r'FRB\s*\d{6,8}[a-zA-Z]*',    # 快速射电暴
            r'GRB\s*\d{6,8}[a-zA-Z]*',    # 伽马射线暴
            r'PSR\s*[BJ]?\d{4}[+-]\d{2,4}', # 脉冲星
            r'SGR\s*\d{4}[+-]\d{2,4}',    # 软伽马重复源
            r'GW\d{6}',                   # 引力波
        ]
        return any(re.search(pattern, value_str, re.IGNORECASE) for pattern in patterns)

    elif field_name == 'instrument':
        # 检查是否是已知的天文设备
        known_instruments = ['nustar', 'chime', 'swift', 'fermi', 'ligo', 'alma',
                           'chandra', 'xmm', 'hubble', 'jwst', 'maxi', 'nicer',
                           'vla', 'vlba', 'askap', 'meerkat', 'fast', 'arecibo']
        return any(inst in value_str.lower() for inst in known_instruments)

    elif field_name == 'date':
        # 检查日期格式
        import re
        date_patterns = [
            r'\d{4}-\d{2}-\d{2}',         # YYYY-MM-DD
            r'\d{4}/\d{2}/\d{2}',         # YYYY/MM/DD
            r'\d{1,2}\s+\w+\s+\d{4}',     # DD Month YYYY
            r'MJD\s*\d{5,6}',             # Modified Julian Date
        ]
        return any(re.search(pattern, value_str) for pattern in date_patterns)

    elif field_name == 'frequency_band':
        # 检查频段格式
        import re
        freq_patterns = [
            r'\d+\.?\d*\s*(hz|khz|mhz|ghz|kev|mev|gev)',  # 频率或能量单位
            r'\d+\.?\d*\s*-\s*\d+\.?\d*\s*(hz|khz|mhz|ghz|kev|mev|gev)',  # 频段范围
            r'(optical|radio|x-ray|gamma-ray|infrared|ultraviolet)',  # 波段名称
        ]
        return any(re.search(pattern, value_str.lower()) for pattern in freq_patterns)

    elif field_name == 'duration':
        # 检查持续时间格式
        import re
        duration_patterns = [
            r'\d+\.?\d*\s*(second|minute|hour|day|week|month|year)s?',
            r'\d+\.?\d*\s*(s|ms|μs|ns|ks)',  # 秒的各种单位
        ]
        return any(re.search(pattern, value_str.lower()) for pattern in duration_patterns)

    elif field_name == 'peak_flux':
        # 检查流量格式
        import re
        flux_patterns = [
            r'\d+\.?\d*e?[+-]?\d*\s*(erg|jy|mjy|μjy)',  # 流量单位
            r'\d+\.?\d*\s*(mag|magnitude)',              # 星等
        ]
        return any(re.search(pattern, value_str.lower()) for pattern in flux_patterns)

    elif field_name == 'counterpart_detected':
        # 检查布尔值
        return value_str.lower() in ['true', 'false', 'yes', 'no', '1', '0']

    # 对于其他字段，只要有非空值就认为有效
    return len(value_str) > 0

def calculate_overall_quality_score(field_analysis, total_successful):
    """
    计算总体质量分数 (0-100)
    """
    if total_successful == 0:
        return 0

    total_score = 0

    # 字段权重（重要字段权重更高）
    field_weights = {
        'event_type': 1.5,
        'event_id': 1.5,
        'instrument': 1.2,
        'date': 1.2,
        'frequency_band': 1.0,
        'duration': 1.0,
        'peak_flux': 0.8,
        'counterpart_detected': 0.8
    }

    total_weight = sum(field_weights.values())

    for field, stats in field_analysis.items():
        weight = field_weights.get(field, 1.0)

        # 计算该字段的分数：填充率 * 有效率
        fill_rate = stats['filled'] / stats['total'] if stats['total'] > 0 else 0
        validity_rate = stats['valid'] / stats['filled'] if stats['filled'] > 0 else 0

        field_score = fill_rate * validity_rate * 100 * weight
        total_score += field_score

    return total_score / total_weight

# 新的主函数
def main():
    """
    主函数 - 直接执行随机抽样处理
    """
    print("天文事件数据AI处理系统 - 随机抽样模式")
    print("="*50)
    print("将从前400条数据中随机抽样10条进行处理")
    print("="*50)

    process_random_sample()

if __name__ == "__main__":
    main()